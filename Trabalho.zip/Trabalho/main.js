const express = require("express")
const app = express()
const port = 3000
const path = require("path");
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
}); 


app.post('/login', (req, res) => {
    const { email, senha } = req.body;

    if (email === 'admin@test.com' && senha === '1234') {
    return res.send('Login OK');
  }
   res.send('Erro no login');

})



app.listen(port, () => {
    console.log(`O servidor está rodando na porta ${port}`)
})